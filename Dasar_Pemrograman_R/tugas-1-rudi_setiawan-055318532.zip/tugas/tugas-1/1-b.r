for (i in 1:25) { print(i) }
