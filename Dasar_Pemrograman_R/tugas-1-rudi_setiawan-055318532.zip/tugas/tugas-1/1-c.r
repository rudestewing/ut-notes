setwd("/Users/rudisetiawan/Repositories/ut-notes/Dasar\ Pemrograman\ R/tugas/data")

data_mahasiswa_csv <- read.csv("data_mahasiswa.csv")

print(data_mahasiswa_csv)
