
my_data <- c(1:5)

data_saya <- c("Andi", "Robert", "Ujang")

kelompokA <- matrix(c(1:9), nrow=3, ncol=3)

dataFrame <- data.frame(
  nilai=c(10,5,6,8,9),mahasiswa=c("Asep", "Kusnaidi", "jajang", "Joko", "Widoy")
)

ls(pat = "y")
