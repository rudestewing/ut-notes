x <- c(2,1,2,4,1,2,3,4,8,3,9)
y <- c(4,3,4,4,3,4,5,2,4,5,3)

# plot
pdf("plot-chart.pdf")
plot(x, y, main="Contoh Plot Chart", xlab="X", ylab="Y", pch=19, col="blue")
