# pengolahan matrix

matrix1 <- matrix(1:12, 3, 4, byrow=TRUE)
print(matrix1)

multiply_value <- 10

matrix_result <- matrix1 * multiply_value
print(matrix_result)
